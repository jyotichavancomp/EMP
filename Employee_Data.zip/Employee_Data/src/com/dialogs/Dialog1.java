package com.dialogs;

import org.eclipse.swt.widgets.Dialog;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.SWT;
//import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.layout.FillLayout;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.layout.FormLayout;
import org.eclipse.swt.layout.FormData;
import org.eclipse.swt.layout.FormAttachment;
import org.eclipse.swt.widgets.Table;
import org.eclipse.swt.widgets.TableColumn;
import org.eclipse.swt.events.MouseAdapter;
import org.eclipse.swt.events.MouseEvent;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Combo;

public class Dialog1 extends Dialog {

	protected Object result;
	protected Shell shell;
	private Composite composite_1;
	private Label lblName;
	private Text Name_text;
	private Label lblAge;
	private Text Age_text;
	private Label lblAddress;
	private Text Address_text;
	private Label lblGender;
	private Table table;
	private TableColumn tblclmnName;
	private TableColumn tblclmnAge;
	private TableColumn tblclmnAddress;
	private TableColumn tblclmnGender;
	//private Text NameTextBox;
	//private Text AgeTextBox;
	

	/**
	 * Create the dialog.
	 * @param parent
	 * @param style
	 */
	public Dialog1(Shell parent, int style) {
		super(parent, style);
		setText("Employee Data");
	}

	/**
	 * Open the dialog.
	 * @return the result
	 */
	public Object open() {
		createContents();
		shell.open();
		shell.layout();
		Display display = getParent().getDisplay();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		return result;
	}

	/**
	 * Create contents of the dialog.
	 */
	private void createContents() {
		shell = new Shell(getParent(), getStyle());
		shell.setSize(450, 571);
		shell.setText(getText());
		shell.setLayout(new FillLayout(SWT.HORIZONTAL));
	//	shell.setLayout(new GridLayout(1, false));
		
		Composite composite = new Composite(shell, SWT.NONE);
		composite.setLayout(new FillLayout(SWT.HORIZONTAL));
		
		composite_1 = new Composite(composite, SWT.NONE);
		composite_1.setLayout(new FormLayout());
		
		lblName = new Label(composite_1, SWT.NONE);
		FormData fd_lblName = new FormData();
		fd_lblName.right = new FormAttachment(0, 55);
		fd_lblName.top = new FormAttachment(0, 10);
		fd_lblName.left = new FormAttachment(0);
		lblName.setLayoutData(fd_lblName);
		lblName.setText("Name");
		
		Name_text = new Text(composite_1, SWT.BORDER);
		FormData fd_Name_text = new FormData();
		fd_Name_text.right = new FormAttachment(0, 365);
		fd_Name_text.top = new FormAttachment(0, 10);
		fd_Name_text.left = new FormAttachment(0, 47);
		Name_text.setLayoutData(fd_Name_text);
		
		lblAge = new Label(composite_1, SWT.NONE);
		FormData fd_lblAge = new FormData();
		fd_lblAge.right = new FormAttachment(0, 55);
		fd_lblAge.top = new FormAttachment(0, 54);
		fd_lblAge.left = new FormAttachment(0);
		lblAge.setLayoutData(fd_lblAge);
		lblAge.setText("Age");
		
		Age_text = new Text(composite_1, SWT.BORDER);
		FormData fd_Age_text = new FormData();
		fd_Age_text.right = new FormAttachment(0, 365);
		fd_Age_text.top = new FormAttachment(0, 54);
		fd_Age_text.left = new FormAttachment(0, 47);
		Age_text.setLayoutData(fd_Age_text);
		
		lblAddress = new Label(composite_1, SWT.NONE);
		FormData fd_lblAddress = new FormData();
		fd_lblAddress.right = new FormAttachment(0, 55);
		fd_lblAddress.top = new FormAttachment(0, 95);
		fd_lblAddress.left = new FormAttachment(0);
		lblAddress.setLayoutData(fd_lblAddress);
		lblAddress.setText("Address");
		
		Address_text = new Text(composite_1, SWT.BORDER);
		FormData fd_Address_text = new FormData();
		fd_Address_text.right = new FormAttachment(0, 365);
		fd_Address_text.top = new FormAttachment(0, 89);
		fd_Address_text.left = new FormAttachment(0, 47);
		Address_text.setLayoutData(fd_Address_text);
		
		lblGender = new Label(composite_1, SWT.NONE);
		FormData fd_lblGender = new FormData();
		fd_lblGender.right = new FormAttachment(0, 55);
		fd_lblGender.top = new FormAttachment(0, 128);
		fd_lblGender.left = new FormAttachment(0);
		lblGender.setLayoutData(fd_lblGender);
		lblGender.setText("Gender");
		
		Button btnSubmit = new Button(composite_1, SWT.NONE);
		btnSubmit.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
			}
		});
		btnSubmit.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDoubleClick(MouseEvent e) {
			}
		});
		FormData fd_btnSubmit = new FormData();
		fd_btnSubmit.right = new FormAttachment(100, -79);
		fd_btnSubmit.left = new FormAttachment(0, 20);
		btnSubmit.setLayoutData(fd_btnSubmit);
		btnSubmit.setText("Submit");
		
		table = new Table(composite_1, SWT.BORDER | SWT.FULL_SELECTION);
		fd_btnSubmit.bottom = new FormAttachment(100, -340);
		FormData fd_table = new FormData();
		fd_table.top = new FormAttachment(btnSubmit, 34);
		fd_table.left = new FormAttachment(btnSubmit, -11, SWT.LEFT);
		fd_table.right = new FormAttachment(Name_text, 0, SWT.RIGHT);
		fd_table.bottom = new FormAttachment(100, -115);
		table.setLayoutData(fd_table);
		table.setHeaderVisible(true);
		table.setLinesVisible(true);
		
		tblclmnName = new TableColumn(table, SWT.NONE);
		tblclmnName.setWidth(70);
		tblclmnName.setText("Name");
		
		tblclmnAge = new TableColumn(table, SWT.NONE);
		tblclmnAge.setWidth(65);
		tblclmnAge.setText("Age");
		
		tblclmnAddress = new TableColumn(table, SWT.NONE);
		tblclmnAddress.setWidth(100);
		tblclmnAddress.setText("Address");
		
		tblclmnGender = new TableColumn(table, SWT.NONE);
		tblclmnGender.setWidth(120);
		tblclmnGender.setText("Gender");
		
		Combo combo = new Combo(composite_1, SWT.NONE);
		combo.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseDown(MouseEvent e) {
			}
		});
		FormData fd_combo = new FormData();
		fd_combo.top = new FormAttachment(lblGender, -3, SWT.TOP);
		fd_combo.left = new FormAttachment(lblGender, 10);
		combo.setLayoutData(fd_combo);

	}
}
