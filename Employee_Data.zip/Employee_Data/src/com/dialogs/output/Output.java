package com.dialogs.output;

public class Output {
	 private static final String filepath="C:\\Users\\snehalk1\\workspace\\Employee_Data\\obj";
	 
	 

}
