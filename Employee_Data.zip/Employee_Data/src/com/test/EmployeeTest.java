package com.test;
import org.eclipse.swt.SWT;

import org.eclipse.swt.widgets.Shell;

import com.dialogs.Dialog1;
//import com.dialogs.JfaceTitleDialog1;
import com.dialogs.JfaceDialog1;
import com.dialogs.JfaceTitleDialog1;


public class EmployeeTest {

	public static void main(String[] args) {
		//Dialog1 dialog1 = new Dialog1(new Shell(),SWT.CLOSE);
		//dialog1.open();
		
		//JfaceDialog1 dialog2 = new JfaceDialog1(new Shell());
		//dialog2.open();
	  JfaceTitleDialog1 dialog3=new JfaceTitleDialog1(new Shell());
	  dialog3.open();

		}
}

